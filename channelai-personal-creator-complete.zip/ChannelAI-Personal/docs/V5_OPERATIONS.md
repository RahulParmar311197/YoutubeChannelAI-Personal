# V5 Operations

## Workflow reliability
- Every generation request should carry `Idempotency-Key`.
- Long-running work belongs in RQ/Redis workers, never inside an HTTP request.
- Poll `/api/workflows/{run_id}` for progress.
- Failed steps must be retryable without duplicating uploads.

## Billing
Stripe Checkout is implemented as a provider boundary. Store Stripe customer/subscription IDs in the tenant billing ledger and process signed webhooks idempotently.

## Publishing
Never publish directly from a browser. The worker owns publishing credentials and writes an audit record.

## Security
Use HTTPS, secure cookies where applicable, strict CORS, secret manager storage, database backups, tenant isolation tests, and rate limiting before exposing the service publicly.

## Content safety
Add a moderation/policy step before rendering and before publishing. Block disallowed content and require review for sensitive categories.
