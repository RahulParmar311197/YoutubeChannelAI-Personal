# ChannelAI V9 — Production Release

V9 is the final integration/release foundation.

## One-click product flow

Create project
-> discover/research
-> generate script
-> generate scenes
-> voice
-> media
-> render
-> captions
-> thumbnail
-> SEO
-> QC
-> moderation
-> human approval (configurable)
-> YouTube schedule/upload
-> analytics
-> learning

## Release controls

`REQUIRE_HUMAN_APPROVAL=true` is the recommended initial production setting.

The system should not publish publicly until:
1. video QC passes
2. moderation passes
3. YouTube OAuth is valid
4. quota is available
5. approval policy is satisfied

## Provider credentials

The application can run locally with fallbacks, but production requires real credentials for:
- LLM
- research/search
- TTS
- media
- object storage
- YouTube
- Stripe
- monitoring

No credentials are embedded in source.
