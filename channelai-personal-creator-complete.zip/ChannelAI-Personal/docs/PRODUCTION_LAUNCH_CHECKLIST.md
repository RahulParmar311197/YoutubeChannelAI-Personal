# Production launch checklist

## Mandatory
- [ ] HTTPS on web and API
- [ ] Strong SECRET_KEY in secret manager
- [ ] TOKEN_ENCRYPTION_KEY configured
- [ ] PostgreSQL backups + restore drill
- [ ] Redis authentication
- [ ] Exact CORS origin
- [ ] Rate limiting
- [ ] Request IDs + structured logs
- [ ] Error monitoring
- [ ] Email verification/password reset
- [ ] Tenant authorization tests
- [ ] OAuth consent + Google verification where required
- [ ] AI provider billing limits
- [ ] Licensed media sources only
- [ ] Video QC before publishing
- [ ] Private/unlisted publishing during initial validation
- [ ] Stripe webhook signature verification
- [ ] Audit log for publishing and billing
- [ ] Data retention/deletion workflow
- [ ] Abuse/content policy enforcement

## Recommended SLOs
API availability: 99.9%
Generation job success: >= 98%
Render success: >= 98%
YouTube upload success: >= 99% excluding quota/auth failures
