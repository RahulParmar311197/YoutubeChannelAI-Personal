# Production acceptance checklist

## Core SaaS
- [ ] signup/login/email verification
- [ ] tenant isolation
- [ ] subscription state
- [ ] usage limits
- [ ] billing webhook idempotency

## Content
- [ ] research citations
- [ ] script quality review
- [ ] licensed media manifest
- [ ] TTS
- [ ] captions
- [ ] thumbnail
- [ ] SEO metadata
- [ ] render
- [ ] QC

## YouTube
- [ ] OAuth
- [ ] private upload test
- [ ] scheduled upload test
- [ ] quota handling
- [ ] retry/idempotency
- [ ] analytics ingestion

## Operations
- [ ] HTTPS
- [ ] backups
- [ ] restore drill
- [ ] error monitoring
- [ ] alerts
- [ ] rate limiting
- [ ] secrets manager
- [ ] cost limits
- [ ] deletion/export

Only enable unattended public publishing after all checks pass.
