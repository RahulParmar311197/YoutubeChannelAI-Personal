# Live YouTube setup

1. Create a Google Cloud project.
2. Enable YouTube Data API v3 and YouTube Analytics API.
3. Configure OAuth consent screen.
4. Create a Web application OAuth client.
5. Set the production redirect URI to:
   `https://api.example.com/api/youtube/oauth/callback`
6. Put the client ID/secret into the production secret manager.
7. Generate a Fernet key and set `TOKEN_ENCRYPTION_KEY`.
8. Deploy the API over HTTPS.
9. Sign in to ChannelAI and start `/api/youtube/oauth/start`.
10. Approve access.
11. Verify `/api/youtube/status`.
12. Upload only after the render/QC pipeline marks a video as ready.

The application requests YouTube upload/read and Analytics read scopes. Public use of OAuth scopes may require Google's verification process.
