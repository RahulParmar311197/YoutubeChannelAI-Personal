# V7 launch architecture

Public SaaS request:
Browser -> CDN/WAF -> Next.js -> API -> PostgreSQL/Redis/object storage.

Generation:
API -> RQ -> worker -> AI/search/TTS/media -> FFmpeg -> QC -> object storage.

Publishing:
QC -> moderation -> approval/publishing gate -> YouTube OAuth/Data API.

Analytics:
YouTube Analytics -> snapshots -> learning -> next content plan.

Operational requirements:
- Secret manager
- HTTPS
- backups
- rate limits
- error monitoring
- structured logs
- alerting
- database migrations
- tenant isolation tests
- content moderation
- provider spending limits
- data deletion/export
