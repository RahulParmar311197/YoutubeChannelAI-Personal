# Production architecture

Browser
  -> Next.js
  -> FastAPI
      -> PostgreSQL
      -> Redis/RQ
      -> AI provider
      -> YouTube OAuth/Data API
      -> YouTube Analytics API
      -> object storage
  -> worker
      -> FFmpeg
      -> media storage

Every tenant-owned query must include organization authorization.
Publishing is an explicit action and should be auditable.
OAuth refresh tokens are encrypted before database storage.
