# Real provider integration

Required before public launch:

## AI
Set `AI_API_KEY`, `AI_MODEL`, and optionally `AI_BASE_URL`.

## Search
Implement the `HttpResearchProvider` contract against a real search/news provider and store source URLs, timestamps and licensing/attribution metadata.

## TTS
Implement `LiveTTSProvider.synthesize()` against the selected TTS vendor. Return a local WAV/MP3 path.

## Media
Implement `LiveMediaProvider.fetch()` only for assets your account is licensed to use. Persist source URL, provider ID and license metadata.

## Storage
Move `./storage` to S3-compatible object storage for production.

## YouTube
Use the existing OAuth/Data API adapter and run the publish gate before upload.
