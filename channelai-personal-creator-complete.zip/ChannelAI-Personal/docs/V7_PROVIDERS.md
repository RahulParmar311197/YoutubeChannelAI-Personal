# V7 provider matrix

The code exposes clean boundaries for production services.

| Capability | Contract | Required for launch |
|---|---|---|
| LLM | OpenAI-compatible provider | Yes |
| Research | ResearchProvider | Yes |
| TTS | TTSProvider | Yes |
| Media | MediaProvider | Yes |
| Storage | Storage | Yes, use object storage |
| Captions | ASR/word timestamps | Recommended |
| Thumbnail | ThumbnailService | Yes |
| YouTube | Data/Analytics API | Yes |
| Billing | Stripe | Yes |
| Observability | logs/errors/metrics | Yes |

Never scrape or reuse media without a license. Store provider/source IDs and license metadata for every externally sourced asset.
