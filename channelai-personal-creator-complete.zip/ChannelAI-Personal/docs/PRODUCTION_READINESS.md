# Production readiness

This codebase is deployment-oriented, but external services must be configured before a real launch.

## Required integrations
1. Real AI provider adapter
2. Real web research/search provider
3. TTS provider
4. Stock/image/video provider
5. Object storage
6. Google OAuth + YouTube Data API
7. YouTube Analytics API
8. Payment provider
9. Email provider

## Security before public launch
- Use a strong secret from a secret manager.
- Never commit `.env`.
- Encrypt YouTube refresh tokens at rest.
- Add refresh-token rotation/revocation.
- Add rate limiting at reverse proxy and API layers.
- Add email verification and password reset.
- Add CSRF protection if cookie sessions are introduced.
- Restrict CORS to the exact web origin.
- Add request IDs and structured logging.
- Add database backups and restore testing.
- Add malware/content validation for user uploads.
- Add per-tenant authorization to every data access path.
- Add quotas and abuse detection.
- Add audit logs for publishing actions.

## Video production
The final renderer should compile a scene timeline:
script -> scene JSON -> asset retrieval -> voice -> captions -> music -> transitions -> FFmpeg -> QC -> object storage.

Do not publish automatically until the render has passed duration, codec, audio, resolution, and file-integrity checks.

## YouTube
Use OAuth and official APIs. Store refresh tokens securely and scope access to the minimum permissions needed. Implement resumable upload, retry/backoff, quota handling, thumbnail upload, scheduling, and analytics synchronization.
