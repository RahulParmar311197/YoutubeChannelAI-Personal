# AI YouTube Autopilot

Production flow:

1. Discover topics for a channel.
2. Research each topic.
3. Score ideas using channel niche, audience and prior performance.
4. Generate title/angle/hook.
5. Generate fact-aware script.
6. Produce scene plan.
7. Generate TTS.
8. Retrieve licensed or generated media.
9. Render with FFmpeg.
10. Run QC.
11. Generate thumbnail/title variants.
12. Schedule/publish through official YouTube APIs.
13. Collect performance metrics.
14. Update channel-level learning signals.
15. Generate the next batch using those signals.

Do not silently auto-publish unreviewed content in a new account. Start with private/unlisted publishing and enable automatic public publishing only after QC and account-level controls are validated.
