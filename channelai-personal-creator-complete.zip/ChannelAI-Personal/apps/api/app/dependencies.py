from fastapi import Header, HTTPException
import jwt
from .config import settings

def current_identity(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        token = authorization.split(" ", 1)[1]
        data = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        return {"user_id": int(data["sub"]), "organization_id": int(data["org"])}
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
