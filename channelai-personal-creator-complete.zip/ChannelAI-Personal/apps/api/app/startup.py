import os
from .services.providers import validate_required_providers

def validate_production_startup():
    if os.getenv("APP_ENV","development") == "production":
        missing=validate_required_providers()
        if missing:
            raise RuntimeError("Production configuration incomplete: "+", ".join(missing))
