from pydantic import BaseModel, Field, EmailStr

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    organization_name: str = Field(min_length=2, max_length=160)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class ChannelCreate(BaseModel):
    name: str
    niche: str = ""
    language: str = "English"
    style: str = "documentary"

class ProjectCreate(BaseModel):
    channel_id: int
    topic: str = Field(min_length=3, max_length=2000)
    title: str = ""
    target_minutes: int = Field(default=10, ge=1, le=60)

class WorkflowCreate(BaseModel):
    generate_video: bool = True
    generate_thumbnail: bool = True

class IdeaRequest(BaseModel):
    niche: str
    audience: str = ""
    count: int = Field(default=10, ge=1, le=50)

class ScriptRequest(BaseModel):
    topic: str
    niche: str = ""
    style: str = "documentary"
    target_minutes: int = Field(default=10, ge=1, le=60)
    language: str = "English"
