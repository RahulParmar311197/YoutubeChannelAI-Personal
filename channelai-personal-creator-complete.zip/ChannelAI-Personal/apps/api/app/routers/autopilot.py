from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import get_db
from ..dependencies import current_identity
from ..services.autopilot import Autopilot
from ..schemas import ChannelCreate

router=APIRouter(prefix="/api/autopilot",tags=["autopilot"])

@router.post("/discover/{channel_id}")
async def discover(channel_id:int,identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    try:
        result=await Autopilot().discover(db,identity["organization_id"],channel_id)
        return {
            "ideas":result["ideas_text"],
            "sources":[x.__dict__ for x in result["research"].sources],
            "research_summary":result["research"].summary
        }
    except ValueError as e: raise HTTPException(404,str(e))

@router.post("/create/{channel_id}")
async def create(channel_id:int,title:str,topic:str,identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    try:
        p=await Autopilot().create_from_idea(db,identity["organization_id"],channel_id,title,topic)
        return {"project_id":p.id,"status":p.status}
    except ValueError as e: raise HTTPException(404,str(e))
