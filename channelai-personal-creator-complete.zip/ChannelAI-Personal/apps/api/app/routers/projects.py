from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..models import ContentProject, WorkflowRun
from ..schemas import ProjectCreate, WorkflowCreate
from ..dependencies import current_identity
from ..services.workflow import ContentWorkflow

router = APIRouter(prefix="/api/projects", tags=["projects"])

@router.get("")
async def list_projects(identity=Depends(current_identity), db: AsyncSession=Depends(get_db)):
    return (await db.execute(
        select(ContentProject)
        .where(ContentProject.organization_id == identity["organization_id"])
        .order_by(ContentProject.id.desc())
    )).scalars().all()

@router.post("")
async def create_project(payload: ProjectCreate, identity=Depends(current_identity), db: AsyncSession=Depends(get_db)):
    row = ContentProject(
        organization_id=identity["organization_id"],
        **payload.model_dump()
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return row

@router.post("/{project_id}/run")
async def run_project(project_id: int, payload: WorkflowCreate, identity=Depends(current_identity), db: AsyncSession=Depends(get_db)):
    try:
        return await ContentWorkflow(db, identity["organization_id"]).execute(
            project_id,
            payload.generate_video,
            payload.generate_thumbnail,
        )
    except ValueError as exc:
        raise HTTPException(404, str(exc))
    except Exception:
        raise HTTPException(500, "Workflow failed; inspect server logs")
