from fastapi import APIRouter,Depends
from ..dependencies import current_identity
from ..services.onboarding import checklist
router=APIRouter(prefix="/api/onboarding",tags=["onboarding"])

@router.get("/checklist")
async def get_checklist(identity=Depends(current_identity)):
    return {"items":checklist()}
