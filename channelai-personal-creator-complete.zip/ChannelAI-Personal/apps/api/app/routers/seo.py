from fastapi import APIRouter,Depends
from ..dependencies import current_identity
from ..services.seo import optimize
router=APIRouter(prefix="/api/seo",tags=["seo"])

@router.post("/optimize")
async def seo(title:str,description:str="",keywords:str="",identity=Depends(current_identity)):
    return optimize(title,description,[x.strip() for x in keywords.split(",") if x.strip()])
