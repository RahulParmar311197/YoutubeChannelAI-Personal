from fastapi import APIRouter
from ..services.providers import validate_required_providers
router=APIRouter(prefix="/api/system",tags=["system"])

@router.get("/configuration")
async def configuration():
    missing=validate_required_providers()
    return {
        "production_ready": not missing,
        "missing": missing,
        "message": "Configuration complete" if not missing else "Add required provider configuration"
    }
