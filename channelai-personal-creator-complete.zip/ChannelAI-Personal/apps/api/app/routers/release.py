from fastapi import APIRouter,Depends
from ..dependencies import current_identity
router=APIRouter(prefix="/api/release",tags=["release"])

@router.get("/status")
async def release_status(identity=Depends(current_identity)):
    return {
      "version":"9.0.0",
      "release":"production-integration",
      "features":{
        "autopilot":True,"generation_pipeline":True,"video_qc":True,
        "captions":True,"thumbnail":True,"seo":True,
        "youtube_publishing":True,"analytics":True,"billing":True
      }
    }
