from fastapi import APIRouter,Depends
from ..dependencies import current_identity
from ..services.strategy import profile
router=APIRouter(prefix="/api/strategy",tags=["strategy"])

@router.get("/{style}")
async def get_strategy(style:str,identity=Depends(current_identity)):
    return profile(style)
