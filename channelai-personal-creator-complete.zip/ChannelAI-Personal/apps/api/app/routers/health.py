from fastapi import APIRouter
import os, time
router=APIRouter(tags=["health"])
START=time.time()

@router.get("/health")
async def health(): return {"status":"ok","uptime_seconds":int(time.time()-START)}

@router.get("/ready")
async def ready():
    checks={"database":bool(os.getenv("DATABASE_URL")),"redis":bool(os.getenv("REDIS_URL"))}
    return {"ready":all(checks.values()),"checks":checks}

@router.get("/metrics")
async def metrics():
    return {"service":"channelai-api","uptime_seconds":int(time.time()-START)}
