from datetime import datetime
from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..dependencies import current_identity
from ..models import PublishingJob, ContentProject
router=APIRouter(prefix="/api/publishing",tags=["publishing"])

@router.post("/schedule/{project_id}")
async def schedule(project_id:int,channel_id:int,scheduled_at:datetime,identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    project=await db.scalar(select(ContentProject).where(
        ContentProject.id==project_id,
        ContentProject.organization_id==identity["organization_id"]
    ))
    if not project: raise HTTPException(404,"Project not found")
    job=PublishingJob(project_id=project_id,channel_id=channel_id,scheduled_at=scheduled_at,status="queued")
    db.add(job); await db.commit(); await db.refresh(job)
    return {"job_id":job.id,"status":"queued","scheduled_at":scheduled_at}

@router.get("/jobs")
async def jobs(identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    rows=(await db.execute(select(PublishingJob).join(ContentProject).where(
        ContentProject.organization_id==identity["organization_id"]
    ).order_by(PublishingJob.id.desc()))).scalars().all()
    return rows
