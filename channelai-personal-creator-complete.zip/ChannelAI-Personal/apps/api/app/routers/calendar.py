from datetime import datetime
from fastapi import APIRouter,Depends
from ..dependencies import current_identity
from ..services.calendar import build_calendar
router=APIRouter(prefix="/api/calendar",tags=["calendar"])

@router.post("/plan")
async def plan(ideas:list[dict],start:datetime,identity=Depends(current_identity)):
    return {"calendar":build_calendar(ideas,start,len(ideas))}
