from fastapi import APIRouter,Depends,Header,HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..dependencies import current_identity
from ..models import ContentProject, WorkflowRun
from ..services.idempotency import get_or_create
from redis import Redis
from rq import Queue
import os

router=APIRouter(prefix="/api/workflows",tags=["workflows"])

@router.post("/projects/{project_id}/generate")
async def generate(project_id:int,
                   identity=Depends(current_identity),
                   db:AsyncSession=Depends(get_db),
                   idempotency_key:str=Header(default="")):
    project=await db.scalar(select(ContentProject).where(
        ContentProject.id==project_id,
        ContentProject.organization_id==identity["organization_id"]
    ))
    if not project: raise HTTPException(404,"Project not found")
    run,created=await get_or_create(db,project.id,idempotency_key)
    await db.commit()
    if created:
        try:
            Queue("generation",connection=Redis.from_url(os.getenv("REDIS_URL","redis://localhost:6379/0"))).enqueue(
                "jobs.generate_project", run.id, job_timeout="30m"
            )
        except Exception as exc:
            run.status="failed"; run.error=f"queue_error: {exc}"; await db.commit()
            raise HTTPException(503,"Generation queue unavailable")
    return {"run_id":run.id,"created":created,"status":run.status}

@router.get("/{run_id}")
async def status(run_id:int,identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    row=await db.scalar(select(WorkflowRun).join(ContentProject).where(
        WorkflowRun.id==run_id,
        ContentProject.organization_id==identity["organization_id"]
    ))
    if not row: raise HTTPException(404,"Run not found")
    return {
        "id":row.id,"status":row.status,"step":row.current_step,
        "progress":row.progress,"error":row.error,"result":row.result_json
    }
