from fastapi import APIRouter,Depends
from ..dependencies import current_identity
from ..services.pipeline import STAGES
router=APIRouter(prefix="/api/pipeline",tags=["pipeline"])

@router.get("/stages")
async def stages(identity=Depends(current_identity)):
    return [{"name":n,"percent":p} for n,p in STAGES]
