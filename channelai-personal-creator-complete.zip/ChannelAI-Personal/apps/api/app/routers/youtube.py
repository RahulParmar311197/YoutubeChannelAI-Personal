from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..config import settings
from ..dependencies import current_identity
from ..models import OAuthState, Channel
from ..services.youtube import authorization_url, exchange_code, save_credentials, get_channel_for_org, credentials_from_channel, upload_video, analytics

router=APIRouter(prefix="/api/youtube",tags=["youtube"])

@router.get("/status")
async def status(identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    channels=(await db.execute(select(Channel).where(Channel.organization_id==identity["organization_id"]))).scalars().all()
    return {"configured":bool(settings.google_client_id and settings.google_client_secret),"channels":[
        {"id":c.id,"name":c.name,"connected":bool(c.youtube_refresh_token),"youtube_channel_id":c.youtube_channel_id}
        for c in channels
    ]}

@router.get("/oauth/start")
async def oauth_start(identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    if not settings.google_client_id or not settings.google_client_secret or not settings.google_redirect_uri:
        raise HTTPException(503,"Google OAuth is not configured")
    state=str(uuid4())
    db.add(OAuthState(organization_id=identity["organization_id"],state=state))
    await db.commit()
    return {"authorization_url":authorization_url(state)}

@router.get("/oauth/callback")
async def oauth_callback(code:str,state:str,db:AsyncSession=Depends(get_db)):
    row=await db.scalar(select(OAuthState).where(OAuthState.state==state))
    if not row:
        raise HTTPException(400,"Invalid OAuth state")
    try:
        credentials=exchange_code(code,state)
        channel=await db.scalar(select(Channel).where(Channel.organization_id==row.organization_id).order_by(Channel.id))
        if not channel:
            raise HTTPException(404,"No channel configured")
        await save_credentials(db,channel,credentials)
        await db.delete(row); await db.commit()
        return {"connected":True,"channel_id":channel.id}
    except Exception as exc:
        raise HTTPException(400,f"YouTube authorization failed: {exc}")

@router.get("/analytics/{channel_id}")
async def get_analytics(channel_id:int,start_date:str,end_date:str,identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    channel=await get_channel_for_org(db,identity["organization_id"],channel_id)
    creds=credentials_from_channel(channel)
    return analytics(creds,channel.youtube_channel_id,start_date,end_date)

@router.post("/upload/{channel_id}")
async def upload(channel_id:int,file_path:str,title:str,description:str="",tags:str="",privacy_status:str="private",identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    channel=await get_channel_for_org(db,identity["organization_id"],channel_id)
    try:
        result=upload_video(channel,file_path,title,description,[x.strip() for x in tags.split(",") if x.strip()],privacy_status)
        return {"uploaded":True,"video":result}
    except Exception as exc:
        raise HTTPException(400,f"YouTube upload failed: {exc}")
