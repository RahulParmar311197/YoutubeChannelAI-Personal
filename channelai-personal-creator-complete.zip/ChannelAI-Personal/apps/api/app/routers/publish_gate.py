from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..dependencies import current_identity
from ..models import ContentProject,VideoProject,Channel
from ..services.moderation import moderate_text
router=APIRouter(prefix="/api/publish",tags=["publishing"])

@router.post("/{project_id}/check")
async def check(project_id:int,identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    p=await db.scalar(select(ContentProject).where(
        ContentProject.id==project_id,ContentProject.organization_id==identity["organization_id"]))
    if not p: raise HTTPException(404,"Project not found")
    v=await db.scalar(select(VideoProject).where(VideoProject.project_id==project_id))
    if not v or not v.render_path: return {"allowed":False,"flags":["video_not_ready"]}
    moderation=moderate_text(p.topic+" "+p.title)
    flags=list(moderation.flags)
    if p.status!="ready": flags.append("project_not_qc_ready")
    return {"allowed":not flags,"flags":flags,"render_path":v.render_path}
