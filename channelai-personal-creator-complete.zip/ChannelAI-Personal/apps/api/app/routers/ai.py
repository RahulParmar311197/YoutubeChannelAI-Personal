import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import get_db
from ..dependencies import current_identity
from ..schemas import IdeaRequest, ScriptRequest
from ..services.ai import get_provider
from ..services.research import get_research_provider

router=APIRouter(prefix="/api/ai",tags=["ai"])

@router.post("/ideas")
async def ideas(payload:IdeaRequest,identity=Depends(current_identity)):
    provider=get_provider()
    result=await provider.generate(
        "You are a YouTube growth strategist.",
        f"IDEAS\nNICHE: {payload.niche}\nAUDIENCE: {payload.audience}\nCOUNT: {payload.count}"
    )
    try:return {"ideas":json.loads(result.text)}
    except:return {"ideas":[{"title":result.text,"score":0}]}

@router.post("/research")
async def research(payload:IdeaRequest,identity=Depends(current_identity)):
    provider=get_research_provider()
    result=await provider.search(payload.niche,payload.count)
    return {
        "query":result.query,
        "summary":result.summary,
        "sources":[s.__dict__ for s in result.sources],
    }

@router.post("/script")
async def script(payload:ScriptRequest,identity=Depends(current_identity)):
    result=await get_provider().generate(
        "You are a professional YouTube writer. Avoid fabricated facts and clearly separate claims from speculation.",
        f"TOPIC: {payload.topic}\nNICHE: {payload.niche}\nSTYLE: {payload.style}\n"
        f"TARGET_MINUTES: {payload.target_minutes}\nLANGUAGE: {payload.language}"
    )
    return {"script":result.text}
