from fastapi import APIRouter,Depends,HTTPException,Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..dependencies import current_identity
from ..models import ContentProject,WorkflowRun
from ..services.idempotency import get_or_create
router=APIRouter(prefix="/api/generate",tags=["generation"])

@router.post("/{project_id}")
async def start(project_id:int,identity=Depends(current_identity),db:AsyncSession=Depends(get_db),
                idempotency_key:str=Header(default="")):
    p=await db.scalar(select(ContentProject).where(
        ContentProject.id==project_id,ContentProject.organization_id==identity["organization_id"]))
    if not p: raise HTTPException(404,"Project not found")
    run,created=await get_or_create(db,p.id,idempotency_key)
    await db.commit()
    return {"run_id":run.id,"created":created,"status":run.status}
