from fastapi import APIRouter,Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..dependencies import current_identity
from ..models import AnalyticsDaily, Channel
from ..services.learning import VideoPerformance, learn_from_history

router=APIRouter(prefix="/api/learning",tags=["learning"])

@router.get("/channel/{channel_id}")
async def channel_learning(channel_id:int,identity=Depends(current_identity),db:AsyncSession=Depends(get_db)):
    channel=await db.scalar(select(Channel).where(Channel.id==channel_id,Channel.organization_id==identity["organization_id"]))
    if not channel: return {"error":"channel_not_found"}
    rows=(await db.execute(select(AnalyticsDaily).where(AnalyticsDaily.channel_id==channel_id))).scalars().all()
    # Aggregate each stored daily row as a learning observation.
    data=[VideoPerformance(views=x.views,watch_time_minutes=x.watch_time_minutes,
        subscribers_gained=x.subscribers_gained,ctr=x.ctr) for x in rows]
    return learn_from_history(data)
