from fastapi import APIRouter,Depends,HTTPException,Request,Header
from ..config import settings
from ..dependencies import current_identity
from ..services.stripe_billing import create_checkout,verify_webhook,PLANS,configured

router=APIRouter(prefix="/api/billing",tags=["billing"])

@router.get("/plans")
async def plans(): return PLANS

@router.get("/status")
async def status(identity=Depends(current_identity)):
    return {"stripe_configured":configured(),"plan":identity.get("plan","starter")}

@router.post("/checkout")
async def checkout(price_id:str,customer_id:str,success_url:str,cancel_url:str,identity=Depends(current_identity)):
    try:
        s=create_checkout(customer_id,price_id,success_url,cancel_url)
        return {"checkout_url":s.url,"session_id":s.id}
    except Exception as e: raise HTTPException(503,str(e))

@router.post("/webhook")
async def webhook(request:Request,stripe_signature:str=Header(default="")):
    payload=await request.body()
    try:
        event=verify_webhook(payload,stripe_signature)
    except Exception as e:
        raise HTTPException(400,str(e))
    # Persist subscription state in your billing ledger here.
    return {"received":True,"type":event["type"]}
