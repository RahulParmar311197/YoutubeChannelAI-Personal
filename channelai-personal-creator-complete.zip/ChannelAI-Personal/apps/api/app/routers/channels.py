from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_db
from ..models import Channel
from ..schemas import ChannelCreate

router = APIRouter(prefix="/api/channels", tags=["channels"])

@router.get("")
async def list_channels(db: AsyncSession = Depends(get_db)):
    return (await db.execute(select(Channel).order_by(Channel.id.desc()))).scalars().all()

@router.post("")
async def create_channel(payload: ChannelCreate, db: AsyncSession = Depends(get_db)):
    channel = Channel(**payload.model_dump())
    db.add(channel)
    await db.commit()
    await db.refresh(channel)
    return channel
