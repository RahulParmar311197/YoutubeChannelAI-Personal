from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    moderation_provider: str = "local"
    ai_base_url: str = "https://api.openai.com/v1"
    research_provider: str = "mock"
    research_api_key: str = ""
    tts_provider: str = "mock"
    tts_api_key: str = ""
    media_provider: str = "mock"
    media_api_key: str = ""
    storage_local_dir: str = "./storage"
    database_url: str = "postgresql+asyncpg://channelai:channelai@localhost:5432/channelai"
    redis_url: str = "redis://localhost:6379/0"
    jwt_secret: str = "change-me"
    ai_provider: str = "mock"
    ai_api_key: str = ""
    ai_model: str = ""
    youtube_client_id: str = ""
    youtube_client_secret: str = ""
    youtube_redirect_uri: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
