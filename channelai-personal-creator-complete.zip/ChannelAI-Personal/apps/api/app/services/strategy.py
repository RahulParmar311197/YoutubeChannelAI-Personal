PROFILES={
 "documentary":{"hook":"curiosity gap","pacing":"medium","visual_density":"high","cta":"soft"},
 "news":{"hook":"breaking update","pacing":"fast","visual_density":"high","cta":"subscribe for updates"},
 "education":{"hook":"problem/solution","pacing":"medium","visual_density":"medium","cta":"learn more"},
 "finance":{"hook":"data-driven question","pacing":"fast","visual_density":"high","cta":"educational disclaimer"},
 "storytelling":{"hook":"cold open","pacing":"medium","visual_density":"high","cta":"soft"},
}

def profile(style:str): return PROFILES.get(style,PROFILES["documentary"])
