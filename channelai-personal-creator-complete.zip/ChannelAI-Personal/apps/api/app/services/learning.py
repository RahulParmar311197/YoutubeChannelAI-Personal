from dataclasses import dataclass
from statistics import mean

@dataclass
class VideoPerformance:
    views:int=0
    watch_time_minutes:float=0
    likes:int=0
    comments:int=0
    subscribers_gained:int=0
    impressions:int=0
    ctr:float=0

def score_video(p:VideoPerformance)->float:
    # Explainable heuristic; replace/augment with trained model once enough channel data exists.
    engagement=(p.likes+p.comments)*100/max(p.views,1)
    retention=p.watch_time_minutes*60/max(p.views,1)
    sub_rate=p.subscribers_gained*100/max(p.views,1)
    ctr_score=min(p.ctr,20)*2
    return round(
        0.45*min(p.views/10000,100)
        + 0.25*min(retention*10,100)
        + 0.10*min(engagement,100)
        + 0.10*min(sub_rate*10,100)
        + 0.10*ctr_score,2
    )

def learn_from_history(rows:list[VideoPerformance])->dict:
    if not rows:
        return {"sample_size":0,"avg_views":0,"avg_ctr":0,"recommended_strategy":"collect more data"}
    ranked=sorted(rows,key=score_video,reverse=True)
    return {
        "sample_size":len(rows),
        "avg_views":round(mean(x.views for x in rows),1),
        "avg_ctr":round(mean(x.ctr for x in rows),2),
        "top_video_score":score_video(ranked[0]),
        "recommended_strategy":"prioritize topics/formats similar to top-performing videos",
    }
