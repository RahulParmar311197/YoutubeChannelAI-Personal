def research_prompt(topic:str,sources:list[dict])->str:
    return f"""You are a fact-aware YouTube researcher.
TOPIC: {topic}
SOURCES:
{sources}
Rules:
- Never invent citations.
- Separate confirmed facts from inference.
- Prefer primary/authoritative sources.
- Flag claims that need verification.
Return a concise evidence map."""

def script_prompt(topic:str,research:str,target_minutes:int,style:str)->str:
    return f"""Write a {target_minutes}-minute {style} YouTube script.
TOPIC: {topic}
RESEARCH:
{research}
Structure:
1. high-retention hook
2. context
3. escalating sections
4. evidence and counterpoints
5. conclusion
6. natural CTA
Do not fabricate facts. Keep claims tied to the supplied research."""
