PLANS={
 "starter":{"monthly_videos":10,"channels":1},
 "creator":{"monthly_videos":50,"channels":3},
 "pro":{"monthly_videos":200,"channels":10},
 "agency":{"monthly_videos":1000,"channels":50},
}

def checklist(channel_connected=False,brand_ready=False,billing_ready=False):
    return [
        {"key":"channel","label":"Connect YouTube channel","done":channel_connected},
        {"key":"brand","label":"Configure channel strategy","done":brand_ready},
        {"key":"billing","label":"Choose subscription plan","done":billing_ready},
    ]
