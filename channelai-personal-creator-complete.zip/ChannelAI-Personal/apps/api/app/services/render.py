import asyncio
import json
import shutil
from pathlib import Path
from ..config import settings

class RenderService:
    def __init__(self):
        self.root=Path(settings.storage_local_dir)
        self.root.mkdir(parents=True,exist_ok=True)

    async def render(self,project_id:int,scene_plan:list,voice_paths:list[str],output_path:str)->str:
        if not shutil.which("ffmpeg"):
            raise RuntimeError("FFmpeg is required for video rendering")
        out=Path(output_path)
        out.parent.mkdir(parents=True,exist_ok=True)
        # Deterministic production contract: create a concat manifest and render each audio
        # track into a black 1920x1080 scene. Replace black source with licensed/AI media.
        manifests=[]
        for i,v in enumerate(voice_paths):
            manifests.append((i,v))
        if not manifests:
            raise RuntimeError("No voice assets to render")
        concat=out.parent/"concat.txt"
        concat.write_text("\n".join(f"file '{Path(v).resolve()}'" for _,v in manifests))
        # For an actual launch, scene-level visual assets are injected here.
        cmd=[
            "ffmpeg","-y","-f","concat","-safe","0","-i",str(concat),
            "-f","lavfi","-i","color=c=black:s=1920x1080:r=30",
            "-shortest","-c:v","libx264","-pix_fmt","yuv420p",
            "-c:a","aac","-movflags","+faststart",str(out)
        ]
        proc=await asyncio.create_subprocess_exec(*cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        _,err=await proc.communicate()
        if proc.returncode:
            raise RuntimeError(err.decode(errors="ignore")[-4000:])
        return str(out)
