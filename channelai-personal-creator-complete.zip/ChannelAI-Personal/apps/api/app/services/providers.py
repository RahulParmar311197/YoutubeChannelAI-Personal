from dataclasses import dataclass
from typing import Protocol
import os

class ProviderConfigurationError(RuntimeError):
    pass

def required(name:str)->str:
    value=os.getenv(name,"").strip()
    if not value or value.startswith("REQUIRED"):
        raise ProviderConfigurationError(f"Missing production configuration: {name}")
    return value

@dataclass
class GeneratedText:
    text:str
    model:str
    usage:dict

class LLMProvider(Protocol):
    async def generate(self, system_prompt:str, user_prompt:str)->GeneratedText: ...

class SearchProvider(Protocol):
    async def search(self, query:str, limit:int=10): ...

class TTSProvider(Protocol):
    async def synthesize(self,text:str,out_path:str)->str: ...

class MediaProvider(Protocol):
    async def search(self,query:str,limit:int=10): ...
    async def download(self,asset,out_path:str)->str: ...

def validate_required_providers():
    names=[
        "AI_API_KEY","AI_MODEL","RESEARCH_PROVIDER","RESEARCH_API_KEY",
        "RESEARCH_API_BASE_URL","TTS_PROVIDER","TTS_API_KEY",
        "TTS_API_BASE_URL","TTS_VOICE_ID","MEDIA_PROVIDER",
        "MEDIA_API_KEY","MEDIA_API_BASE_URL","S3_BUCKET","S3_ENDPOINT",
        "S3_REGION","S3_ACCESS_KEY","S3_SECRET_KEY",
        "GOOGLE_CLIENT_ID","GOOGLE_CLIENT_SECRET","STRIPE_SECRET_KEY",
        "STRIPE_WEBHOOK_SECRET","SMTP_HOST","SMTP_USERNAME","SMTP_PASSWORD"
    ]
    missing=[]
    for n in names:
        try: required(n)
        except ProviderConfigurationError: missing.append(n)
    return missing
