import asyncio, shutil
from pathlib import Path

async def generate_srt(audio_path:str,out_path:str,text:str)->str:
    # Deterministic caption fallback. For production, replace with word-timestamp ASR.
    Path(out_path).parent.mkdir(parents=True,exist_ok=True)
    duration=max(1,len(text.split())//2)
    lines=[]
    words=text.split()
    chunk=words[:12]
    start=0
    idx=1
    while chunk:
        end=min(duration,start+5)
        def ts(x):
            h=x//3600;m=(x%3600)//60;s=x%60
            return f"{h:02d}:{m:02d}:{s:02d},000"
        lines.append(f"{idx}\n{ts(start)} --> {ts(end)}\n{' '.join(chunk)}\n")
        idx+=1; start=end; words=words[12:]; chunk=words[:12]
    Path(out_path).write_text("\n".join(lines),encoding="utf-8")
    return out_path
