import stripe
from ..config import settings

PLANS={
    "starter":{"videos":10,"price_env":"STRIPE_PRICE_STARTER"},
    "creator":{"videos":50,"price_env":"STRIPE_PRICE_CREATOR"},
    "pro":{"videos":200,"price_env":"STRIPE_PRICE_PRO"},
    "agency":{"videos":1000,"price_env":"STRIPE_PRICE_AGENCY"},
}

def configured():
    return bool(settings.stripe_secret_key)

def create_checkout(customer_id:str,price_id:str,success_url:str,cancel_url:str):
    if not configured(): raise RuntimeError("Stripe is not configured")
    stripe.api_key=settings.stripe_secret_key
    return stripe.checkout.Session.create(
        mode="subscription",
        customer=customer_id,
        line_items=[{"price":price_id,"quantity":1}],
        success_url=success_url,
        cancel_url=cancel_url,
        allow_promotion_codes=True,
    )

def verify_webhook(payload:bytes,signature:str):
    if not settings.stripe_webhook_secret: raise RuntimeError("Stripe webhook secret missing")
    stripe.api_key=settings.stripe_secret_key
    return stripe.Webhook.construct_event(payload,signature,settings.stripe_webhook_secret)
