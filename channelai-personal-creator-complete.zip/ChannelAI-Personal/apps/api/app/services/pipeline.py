from dataclasses import dataclass

@dataclass
class PipelineState:
    project_id:int
    run_id:int
    stage:str="queued"
    percent:int=0
    error:str|None=None

STAGES=[
    ("research",10),("script",25),("scene_plan",40),("voice",55),
    ("media",65),("render",78),("captions",84),("thumbnail",88),
    ("seo",92),("qc",96),("ready",100)
]

def next_stage(stage:str):
    for i,(name,pct) in enumerate(STAGES):
        if name==stage:
            return STAGES[i+1] if i+1<len(STAGES) else None
    return STAGES[0]
