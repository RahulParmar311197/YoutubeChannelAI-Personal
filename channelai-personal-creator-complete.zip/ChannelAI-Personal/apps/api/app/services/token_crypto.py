import os
from cryptography.fernet import Fernet

_key=os.getenv("TOKEN_ENCRYPTION_KEY","")
if _key:
    _fernet=Fernet(_key.encode())
else:
    _fernet=None

def encrypt(value:str)->str:
    if not _fernet:
        raise RuntimeError("TOKEN_ENCRYPTION_KEY is required for OAuth token storage")
    return _fernet.encrypt(value.encode()).decode()

def decrypt(value:str)->str:
    if not _fernet:
        raise RuntimeError("TOKEN_ENCRYPTION_KEY is required for OAuth token storage")
    return _fernet.decrypt(value.encode()).decode()
