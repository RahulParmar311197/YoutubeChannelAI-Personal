import io
from datetime import datetime, timedelta
from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..config import settings
from ..models import Channel
from .token_crypto import encrypt, decrypt

SCOPES=[
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube.readonly",
    "https://www.googleapis.com/auth/yt-analytics.readonly",
]

def client_config():
    return {
        "web":{
            "client_id":settings.google_client_id,
            "client_secret":settings.google_client_secret,
            "auth_uri":"https://accounts.google.com/o/oauth2/auth",
            "token_uri":"https://oauth2.googleapis.com/token",
            "redirect_uris":[settings.google_redirect_uri],
        }
    }

def make_flow(state=None):
    flow=Flow.from_client_config(client_config(),scopes=SCOPES,state=state)
    flow.redirect_uri=settings.google_redirect_uri
    return flow

def authorization_url(state:str):
    flow=make_flow()
    url,_=flow.authorization_url(
        access_type="offline",
        include_granted_scopes="true",
        prompt="consent",
        state=state,
    )
    return url

def exchange_code(code:str,state:str):
    flow=make_flow(state)
    flow.fetch_token(code=code)
    return flow.credentials

def credentials_from_channel(channel:Channel):
    if not channel.youtube_refresh_token:
        raise RuntimeError("YouTube channel is not connected")
    refresh=decrypt(channel.youtube_refresh_token)
    access=decrypt(channel.youtube_access_token) if channel.youtube_access_token else None
    return Credentials(
        token=access,
        refresh_token=refresh,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=settings.google_client_id,
        client_secret=settings.google_client_secret,
        scopes=SCOPES,
    )

async def save_credentials(db:AsyncSession,channel:Channel,credentials:Credentials):
    youtube=build("youtube","v3",credentials=credentials)
    data=youtube.channels().list(part="id,snippet",mine=True).execute()
    items=data.get("items",[])
    if not items:
        raise RuntimeError("No YouTube channel found for this Google account")
    channel.youtube_channel_id=items[0]["id"]
    channel.youtube_access_token=encrypt(credentials.token)
    channel.youtube_refresh_token=encrypt(credentials.refresh_token)
    await db.commit()
    return channel

async def get_channel_for_org(db:AsyncSession,org_id:int,channel_id:int):
    row=await db.scalar(select(Channel).where(
        Channel.id==channel_id,
        Channel.organization_id==org_id
    ))
    if not row:
        raise RuntimeError("Channel not found")
    return row

def upload_video(channel:Channel,file_path:str,title:str,description:str,tags:list[str],privacy_status="private"):
    credentials=credentials_from_channel(channel)
    youtube=build("youtube","v3",credentials=credentials)
    body={
        "snippet":{
            "title":title[:100],
            "description":description[:5000],
            "tags":tags[:500],
            "categoryId":"22",
        },
        "status":{"privacyStatus":privacy_status,"selfDeclaredMadeForKids":False},
    }
    request=youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=MediaFileUpload(file_path,chunksize=8*1024*1024,resumable=True),
    )
    response=None
    while response is None:
        _,response=request.next_chunk()
    return response

def analytics(credentials:Credentials,channel_id:str,start_date:str,end_date:str):
    api=build("youtubeAnalytics","v2",credentials=credentials)
    return api.reports().query(
        ids=f"channel=={channel_id}",
        startDate=start_date,
        endDate=end_date,
        metrics="views,estimatedMinutesWatched,averageViewDuration,subscribersGained",
        dimensions="day",
    ).execute()
