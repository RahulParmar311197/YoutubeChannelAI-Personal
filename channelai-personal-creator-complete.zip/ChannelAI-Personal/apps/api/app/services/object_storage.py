import os
from pathlib import Path

class ObjectStorage:
    def __init__(self):
        self.bucket=os.getenv("S3_BUCKET")
        self.endpoint=os.getenv("S3_ENDPOINT")
        self.local_root=Path(os.getenv("STORAGE_LOCAL_DIR","./storage"))
        self.local_root.mkdir(parents=True,exist_ok=True)

    def put(self,local_path,key):
        # Local fallback. Configure boto3/S3-compatible storage for production.
        target=self.local_root/key
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(Path(local_path).read_bytes())
        return str(target)

    def public_url(self,key):
        base=os.getenv("PUBLIC_MEDIA_URL","/media").rstrip("/")
        return f"{base}/{key}"
