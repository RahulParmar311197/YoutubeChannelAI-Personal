from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

class ThumbnailService:
    def generate(self,title:str,out_path:str)->str:
        Path(out_path).parent.mkdir(parents=True,exist_ok=True)
        img=Image.new("RGB",(1280,720),(18,18,18))
        draw=ImageDraw.Draw(img)
        font=ImageFont.load_default(size=54)
        # Production-safe deterministic placeholder; plug in an image model for final creatives.
        text=title[:80]
        draw.multiline_text((60,270),text,fill="white",font=font,spacing=12)
        img.save(out_path,"JPEG",quality=92)
        return out_path
