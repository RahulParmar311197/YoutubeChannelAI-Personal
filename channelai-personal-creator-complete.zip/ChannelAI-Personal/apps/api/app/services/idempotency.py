import hashlib, json
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..models import WorkflowRun

async def get_or_create(db:AsyncSession,project_id:int,key:str):
    if not key: raise HTTPException(400,"Idempotency-Key is required")
    row=await db.scalar(select(WorkflowRun).where(WorkflowRun.idempotency_key==key))
    if row: return row,False
    row=WorkflowRun(project_id=project_id,idempotency_key=key,status="queued",current_step="queued")
    db.add(row); await db.flush()
    return row,True
