from dataclasses import dataclass

@dataclass
class Variant:
    id:str
    title:str
    thumbnail_prompt:str

def choose_variant(variants:list[Variant],performance:dict)->Variant:
    # Deterministic baseline. Replace with contextual bandit once variant sample size is adequate.
    if not variants: raise ValueError("No variants")
    return variants[0]
