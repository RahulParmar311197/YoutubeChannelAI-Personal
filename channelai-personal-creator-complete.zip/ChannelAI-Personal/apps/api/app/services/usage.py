from dataclasses import dataclass

@dataclass
class PlanLimit:
    monthly_generations:int
    monthly_channels:int

PLANS={
 "starter":PlanLimit(10,1),
 "creator":PlanLimit(50,3),
 "pro":PlanLimit(200,10),
 "agency":PlanLimit(1000,50),
}

def within_generation_limit(plan:str,used:int)->bool:
    return used < PLANS.get(plan,PLANS["starter"]).monthly_generations
