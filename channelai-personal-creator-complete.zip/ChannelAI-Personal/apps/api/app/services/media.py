from pathlib import Path
from ..config import settings

class MediaProvider:
    async def fetch(self,query:str,out_path:str)->str:
        raise NotImplementedError

class MockMediaProvider(MediaProvider):
    async def fetch(self,query:str,out_path:str)->str:
        # A black video asset is intentionally used as a deterministic local fixture.
        Path(out_path).parent.mkdir(parents=True,exist_ok=True)
        return out_path

class LiveMediaProvider(MediaProvider):
    async def fetch(self,query:str,out_path:str)->str:
        if not settings.media_api_key:
            raise RuntimeError("MEDIA_API_KEY is required")
        raise RuntimeError("Implement selected licensed stock/media provider adapter.")

def get_media_provider():
    return MockMediaProvider() if settings.media_provider=="mock" else LiveMediaProvider()
