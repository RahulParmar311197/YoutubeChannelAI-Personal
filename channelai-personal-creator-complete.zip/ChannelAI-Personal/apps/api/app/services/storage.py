from pathlib import Path
from ..config import settings

class Storage:
    def __init__(self):
        self.root=Path(settings.storage_local_dir)
        self.root.mkdir(parents=True,exist_ok=True)

    def path(self,key:str)->str:
        p=self.root/key
        p.parent.mkdir(parents=True,exist_ok=True)
        return str(p)

    def put(self,local_path:str,key:str)->str:
        target=Path(self.path(key))
        target.write_bytes(Path(local_path).read_bytes())
        return str(target)

    def url(self,key:str)->str:
        return f"/media/{key}"
