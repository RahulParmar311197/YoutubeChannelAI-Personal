import json, shutil, subprocess
from pathlib import Path

class VideoQC:
    def inspect(self,path:str)->dict:
        p=Path(path)
        if not p.exists(): return {"passed":False,"errors":["file_missing"]}
        if p.stat().st_size < 10000: return {"passed":False,"errors":["file_too_small"]}
        if not shutil.which("ffprobe"): return {"passed":False,"errors":["ffprobe_missing"]}
        cmd=["ffprobe","-v","error","-show_entries","format=duration:stream=codec_name,width,height","-of","json",str(p)]
        r=subprocess.run(cmd,capture_output=True,text=True)
        if r.returncode: return {"passed":False,"errors":["invalid_media"]}
        try: data=json.loads(r.stdout)
        except: return {"passed":False,"errors":["invalid_probe_json"]}
        errors=[]
        streams=data.get("streams",[])
        video=next((x for x in streams if x.get("width")),None)
        if not video: errors.append("video_stream_missing")
        elif video.get("width",0)<1280 or video.get("height",0)<720: errors.append("resolution_below_720p")
        duration=float(data.get("format",{}).get("duration") or 0)
        if duration<10: errors.append("duration_too_short")
        return {"passed":not errors,"errors":errors,"duration":duration,"streams":streams}
