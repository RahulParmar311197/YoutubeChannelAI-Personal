import json
from dataclasses import dataclass
from ..config import settings

@dataclass
class AIResult:
    text: str
    structured: object | None = None

class AIProvider:
    async def generate(self, system: str, user: str) -> AIResult:
        raise NotImplementedError

class MockAIProvider(AIProvider):
    async def generate(self, system: str, user: str) -> AIResult:
        if "IDEAS" in user:
            niche = user.split("NICHE:", 1)[-1].split("\n", 1)[0].strip()
            ideas = [
                {"title": f"The Hidden Story Behind {niche}", "score": 93},
                {"title": f"What Nobody Tells You About {niche}", "score": 89},
                {"title": f"The Future of {niche}", "score": 86},
            ]
            return AIResult(json.dumps(ideas), ideas)

        topic = user.split("TOPIC:", 1)[-1].split("\n", 1)[0].strip()
        text = (
            f"HOOK\nWhat if the biggest story about {topic} is not the obvious one?\n\n"
            f"INTRO\nToday we examine {topic}, the key evidence, the major developments, "
            "and what viewers should watch next.\n\n"
            "SECTION 1\nExplain the verified background and important terms.\n\n"
            "SECTION 2\nExplain the timeline, developments, evidence, and competing explanations.\n\n"
            "SECTION 3\nExplain implications and separate facts from speculation.\n\n"
            "CONCLUSION\nFocus on what the available evidence actually supports.\n\n"
            "CTA\nSubscribe for more researched explainers."
        )
        return AIResult(text)

class LiveProvider(AIProvider):
    async def generate(self, system: str, user: str) -> AIResult:
        if not settings.ai_api_key:
            raise RuntimeError("AI_API_KEY is not configured")
        raise RuntimeError(
            "Install/configure your selected AI vendor adapter in this class before enabling live generation."
        )

def get_provider() -> AIProvider:
    return MockAIProvider() if settings.ai_provider == "mock" else LiveProvider()
