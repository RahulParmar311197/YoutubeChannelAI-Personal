from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import httpx
from ..config import settings

@dataclass
class ResearchSource:
    title: str
    url: str
    snippet: str
    published_at: str = ""

@dataclass
class ResearchResult:
    query: str
    sources: list[ResearchSource]
    summary: str

class ResearchProvider:
    async def search(self, query: str, limit: int = 10) -> ResearchResult:
        raise NotImplementedError

class MockResearchProvider(ResearchProvider):
    async def search(self, query: str, limit: int = 10) -> ResearchResult:
        sources=[
            ResearchSource(
                title=f"Research lead: {query}",
                url="https://example.com/research",
                snippet=f"Research placeholder for {query}. Replace mock provider before production.",
                published_at=datetime.now(timezone.utc).isoformat(),
            )
        ]
        return ResearchResult(query,sources,f"Research summary placeholder for {query}.")

class HttpResearchProvider(ResearchProvider):
    async def search(self, query: str, limit: int = 10) -> ResearchResult:
        if not settings.research_api_key:
            raise RuntimeError("RESEARCH_API_KEY is required")
        # Vendor-neutral contract. Wire your selected compliant search API here.
        async with httpx.AsyncClient(timeout=20) as client:
            r=await client.get(
                "https://api.example.com/search",
                params={"q":query,"limit":limit},
                headers={"Authorization":f"Bearer {settings.research_api_key}"},
            )
            r.raise_for_status()
            data=r.json()
        sources=[ResearchSource(
            title=x.get("title",""),
            url=x.get("url",""),
            snippet=x.get("snippet",""),
            published_at=x.get("published_at",""),
        ) for x in data.get("results",[])]
        return ResearchResult(query,sources,data.get("summary",""))

def get_research_provider():
    return MockResearchProvider() if settings.research_provider=="mock" else HttpResearchProvider()
