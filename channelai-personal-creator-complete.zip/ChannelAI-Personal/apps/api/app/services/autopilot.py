from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..models import Channel, ContentProject, UsageEvent
from .research import get_research_provider
from .ai import get_provider

class Autopilot:
    async def discover(self,db:AsyncSession,organization_id:int,channel_id:int):
        channel=await db.scalar(select(Channel).where(
            Channel.id==channel_id,Channel.organization_id==organization_id
        ))
        if not channel: raise ValueError("Channel not found")
        research=await get_research_provider().search(channel.niche or "YouTube trends",10)
        prompt=(
            f"IDEAS\nNICHE: {channel.niche}\nAUDIENCE: general\n"
            f"RESEARCH: {research.summary}\n"
            "Return 10 ideas as JSON with title, angle, hook, score, risk."
        )
        result=await get_provider().generate("YouTube growth strategist",prompt)
        return {"research":research,"ideas_text":result.text}

    async def create_from_idea(self,db:AsyncSession,organization_id:int,channel_id:int,title:str,topic:str):
        project=ContentProject(
            organization_id=organization_id,
            channel_id=channel_id,
            title=title,
            topic=topic,
            status="idea",
            target_minutes=10,
        )
        db.add(project)
        db.add(UsageEvent(
            organization_id=organization_id,
            event_type="autopilot_project",
            units=1,
            metadata_json={"topic":topic}
        ))
        await db.commit(); await db.refresh(project)
        return project
