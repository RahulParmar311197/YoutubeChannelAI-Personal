from pathlib import Path
import wave, math, struct
from ..config import settings

class TTSProvider:
    async def synthesize(self,text:str,out_path:str)->str:
        raise NotImplementedError

class MockTTSProvider(TTSProvider):
    async def synthesize(self,text:str,out_path:str)->str:
        # Generates a valid WAV placeholder so the render pipeline can be exercised end-to-end.
        Path(out_path).parent.mkdir(parents=True,exist_ok=True)
        rate=22050
        seconds=max(1,min(12,len(text)/90))
        frames=int(rate*seconds)
        with wave.open(out_path,"w") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
            for i in range(frames):
                value=int(1200*math.sin(2*math.pi*440*i/rate))
                w.writeframes(struct.pack("<h",value))
        return out_path

class LiveTTSProvider(TTSProvider):
    async def synthesize(self,text:str,out_path:str)->str:
        if not settings.tts_api_key:
            raise RuntimeError("TTS_API_KEY is required")
        raise RuntimeError("Implement the selected TTS vendor adapter before enabling live TTS.")

def get_tts_provider():
    return MockTTSProvider() if settings.tts_provider=="mock" else LiveTTSProvider()
