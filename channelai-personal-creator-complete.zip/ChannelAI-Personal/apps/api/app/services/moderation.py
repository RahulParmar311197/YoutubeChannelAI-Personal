class ModerationResult:
    def __init__(self,allowed:bool,flags:list[str]):
        self.allowed=allowed; self.flags=flags

def moderate_text(text:str)->ModerationResult:
    # Conservative local gate. Replace with your chosen moderation provider.
    banned=["instruction to build a weapon","targeted harassment"]
    flags=[x for x in banned if x.lower() in text.lower()]
    return ModerationResult(not flags,flags)
