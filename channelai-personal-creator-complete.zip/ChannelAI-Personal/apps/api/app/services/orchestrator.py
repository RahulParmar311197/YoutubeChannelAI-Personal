from dataclasses import dataclass
from pathlib import Path
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..models import ContentProject, Script, ScenePlan, VideoProject, Thumbnail, WorkflowRun, UsageEvent
from .research import get_research_provider
from .ai import get_provider
from .prompting import research_prompt, script_prompt
from .tts import get_tts_provider
from .render import RenderService
from .qc import VideoQC
from .captions import generate_srt
from .thumbnail import ThumbnailService
from .storage import Storage
from .seo import optimize

@dataclass
class GenerationResult:
    project_id:int
    run_id:int
    video_path:str|None
    qc:dict
    status:str

class GenerationOrchestrator:
    async def run(self,db:AsyncSession,run_id:int)->GenerationResult:
        run=await db.get(WorkflowRun,run_id)
        if not run: raise ValueError("Workflow run not found")
        project=await db.get(ContentProject,run.project_id)
        if not project: raise ValueError("Project not found")
        base=Path("./storage")/str(project.id)
        base.mkdir(parents=True,exist_ok=True)

        async def step(name,progress):
            run.current_step=name; run.progress=progress; await db.commit()

        try:
            await step("research",10)
            research=await get_research_provider().search(project.topic,10)
            sources=[s.__dict__ for s in research.sources]

            await step("script",25)
            rp=research_prompt(project.topic,sources)
            sp=script_prompt(project.topic,research.summary,project.target_minutes,
                             project.metadata_json.get("style","documentary"))
            script_text=(await get_provider().generate(rp,sp)).text

            script=Script(project_id=project.id,version=1,title=project.title,
                          body=script_text,outline_json={},sources_json=sources)
            db.add(script); await db.flush()

            await step("scene_plan",40)
            scenes=[{"index":1,"narration":script_text,"visual_query":project.topic}]
            db.add(ScenePlan(project_id=project.id,version=1,scenes_json=scenes))
            await db.flush()

            await step("voice",55)
            voice=base/"voice.wav"
            await get_tts_provider().synthesize(script_text,str(voice))

            await step("render",75)
            video=base/"final.mp4"
            path=await RenderService().render(project.id,scenes,[str(voice)],str(video))

            await step("captions",82)
            captions=base/"captions.srt"
            await generate_srt(str(voice),str(captions),script_text)

            await step("thumbnail",86)
            thumbnail_path=base/"thumbnail.jpg"
            ThumbnailService().generate(project.title,str(thumbnail_path))

            await step("seo",89)
            seo=optimize(project.title,project.topic,project.topic.split()[:8])

            await step("qc",92)
            qc=VideoQC().inspect(path)
            if not qc["passed"]:
                run.status="failed"; run.error=";".join(qc["errors"])
                project.status="qc_failed"; await db.commit()
                return GenerationResult(project.id,run.id,path,qc,"failed")

            existing=await db.scalar(select(VideoProject).where(VideoProject.project_id==project.id))
            if not existing:
                existing=VideoProject(project_id=project.id)
                db.add(existing)
            existing.status="ready"; existing.render_path=path
            existing.duration_seconds=int(qc.get("duration",0))
            project.metadata_json={**(project.metadata_json or {}),"captions":str(captions),"thumbnail":str(thumbnail_path),"seo":seo}
            project.status="ready"
            run.status="completed"; run.progress=100; run.current_step="completed"
            run.result_json={"video_path":path,"qc":qc}
            db.add(UsageEvent(organization_id=project.organization_id,
                              event_type="video_generation",units=1,
                              metadata_json={"project_id":project.id}))
            await db.commit()
            return GenerationResult(project.id,run.id,path,qc,"completed")
        except Exception as exc:
            run.status="failed"; run.error=str(exc); project.status="failed"
            await db.commit()
            return GenerationResult(project.id,run.id,None,{"passed":False,"errors":[str(exc)]},"failed")
