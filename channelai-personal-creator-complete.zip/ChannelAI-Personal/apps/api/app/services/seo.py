import re
def optimize(title:str,description:str,keywords:list[str])->dict:
    clean_title=re.sub(r"\s+"," ",title).strip()[:100]
    tags=[]
    for k in keywords:
        k=re.sub(r"[^\w\s-]","",k).strip()
        if k and k.lower() not in {x.lower() for x in tags}: tags.append(k[:30])
    desc=description.strip()
    if len(desc)<120:
        desc += "\n\n" + " ".join(f"#{x.replace(' ','')}" for x in tags[:5])
    return {"title":clean_title,"description":desc[:5000],"tags":tags[:30]}
