from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..models import ContentProject, Script, ScenePlan, VideoProject, Thumbnail, WorkflowRun, UsageEvent
from .ai import get_provider

class ContentWorkflow:
    def __init__(self, db: AsyncSession, organization_id: int):
        self.db = db
        self.organization_id = organization_id
        self.ai = get_provider()

    async def execute(self, project_id: int, generate_video=True, generate_thumbnail=True):
        project = await self.db.scalar(
            select(ContentProject).where(
                ContentProject.id == project_id,
                ContentProject.organization_id == self.organization_id,
            )
        )
        if not project:
            raise ValueError("Project not found")

        run = WorkflowRun(
            project_id=project_id,
            idempotency_key=str(uuid4()),
            status="running",
            current_step="research",
            progress=5,
        )
        self.db.add(run)
        self.db.add(UsageEvent(
            organization_id=self.organization_id,
            event_type="video_generation",
            units=1,
        ))
        await self.db.commit()

        try:
            research = await self.ai.generate(
                "You are a YouTube research strategist.",
                f"RESEARCH TOPIC: {project.topic}",
            )

            run.current_step, run.progress = "script", 25
            script = await self.ai.generate(
                "You are a professional YouTube scriptwriter.",
                f"TOPIC: {project.topic}\nTARGET: {project.target_minutes} minutes",
            )
            self.db.add(Script(
                project_id=project_id,
                title=project.title or project.topic,
                body=script.text,
                outline_json={"research": research.text},
            ))

            run.current_step, run.progress = "scene_plan", 45
            self.db.add(ScenePlan(
                project_id=project_id,
                scenes_json=[{
                    "index": 1,
                    "duration": 8,
                    "narration": script.text[:500],
                    "visual_prompt": f"Cinematic documentary visual for {project.topic}",
                }],
            ))

            if generate_video:
                self.db.add(VideoProject(project_id=project_id, status="queued"))
            if generate_thumbnail:
                self.db.add(Thumbnail(
                    project_id=project_id,
                    prompt=f"Professional YouTube thumbnail for {project.topic}",
                ))

            project.status = "ready"
            run.current_step = "ready"
            run.progress = 100
            run.status = "completed"
            await self.db.commit()
            return {"workflow_id": run.id, "status": "completed"}
        except Exception as exc:
            run.status = "failed"
            run.error = str(exc)
            project.status = "failed"
            await self.db.commit()
            raise
