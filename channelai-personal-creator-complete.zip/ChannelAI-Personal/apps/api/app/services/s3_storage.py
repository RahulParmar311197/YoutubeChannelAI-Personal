import os
from pathlib import Path
import boto3

class S3Storage:
    def __init__(self):
        self.bucket=os.environ["S3_BUCKET"]
        self.client=boto3.client(
            "s3",
            endpoint_url=os.environ.get("S3_ENDPOINT") or None,
            region_name=os.environ.get("S3_REGION"),
            aws_access_key_id=os.environ["S3_ACCESS_KEY"],
            aws_secret_access_key=os.environ["S3_SECRET_KEY"],
        )

    def upload(self, local_path:str, key:str, content_type:str|None=None):
        extra={"ContentType":content_type} if content_type else {}
        self.client.upload_file(local_path,self.bucket,key,ExtraArgs=extra)
        base=os.environ.get("PUBLIC_MEDIA_URL","").rstrip("/")
        return f"{base}/{key}" if base else key

    def delete(self,key:str):
        self.client.delete_object(Bucket=self.bucket,Key=key)
