from dataclasses import dataclass,asdict
from datetime import datetime,timezone

@dataclass
class Asset:
    provider:str
    provider_id:str
    url:str
    license_name:str
    license_url:str|None=None
    attribution:str|None=None
    downloaded_at:str|None=None

def manifest(asset:Asset):
    x=asdict(asset)
    x["downloaded_at"]=x["downloaded_at"] or datetime.now(timezone.utc).isoformat()
    return x
