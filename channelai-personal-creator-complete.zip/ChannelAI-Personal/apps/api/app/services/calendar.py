from datetime import datetime, timedelta

def next_slots(start:datetime,count:int,days=(1,3,5)):
    slots=[]
    cur=start
    i=0
    while len(slots)<count:
        if cur.weekday() in days:
            slots.append(cur)
        cur+=timedelta(days=1)
        i+=1
        if i>60: break
    return slots

def build_calendar(ideas:list[dict],start:datetime,count:int):
    slots=next_slots(start,count)
    return [
        {"scheduled_at":slots[i].isoformat(),"idea":ideas[i]}
        for i in range(min(len(slots),len(ideas)))
    ]
