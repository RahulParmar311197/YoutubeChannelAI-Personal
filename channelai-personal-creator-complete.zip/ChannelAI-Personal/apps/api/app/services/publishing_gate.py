def can_publish(*,qc_passed:bool,moderation_passed:bool,approval_required:bool,approved:bool,
                youtube_connected:bool,quota_available:bool):
    flags=[]
    if not qc_passed: flags.append("qc_failed")
    if not moderation_passed: flags.append("moderation_failed")
    if approval_required and not approved: flags.append("approval_required")
    if not youtube_connected: flags.append("youtube_not_connected")
    if not quota_available: flags.append("youtube_quota_unavailable")
    return {"allowed":not flags,"flags":flags}
