from datetime import datetime
from sqlalchemy import String, Text, DateTime, ForeignKey, JSON, Integer, Boolean, UniqueConstraint, BigInteger
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

def now(): return datetime.utcnow()

class Organization(Base):
    __tablename__="organizations"
    id:Mapped[int]=mapped_column(primary_key=True)
    name:Mapped[str]=mapped_column(String(160))
    plan:Mapped[str]=mapped_column(String(40),default="starter")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    email:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(255))
    is_active:Mapped[bool]=mapped_column(Boolean,default=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class Channel(Base):
    __tablename__="channels"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    name:Mapped[str]=mapped_column(String(160))
    niche:Mapped[str]=mapped_column(String(255),default="")
    language:Mapped[str]=mapped_column(String(30),default="English")
    style:Mapped[str]=mapped_column(String(80),default="documentary")
    youtube_channel_id:Mapped[str|None]=mapped_column(String(255))
    youtube_access_token:Mapped[str|None]=mapped_column(Text)
    youtube_refresh_token:Mapped[str|None]=mapped_column(Text)

class OAuthState(Base):
    __tablename__="oauth_states"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    state:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class ContentProject(Base):
    __tablename__="content_projects"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    channel_id:Mapped[int]=mapped_column(ForeignKey("channels.id"),index=True)
    title:Mapped[str]=mapped_column(String(500))
    topic:Mapped[str]=mapped_column(String(2000))
    status:Mapped[str]=mapped_column(String(50),default="idea",index=True)
    target_minutes:Mapped[int]=mapped_column(Integer,default=10)
    metadata_json:Mapped[dict]=mapped_column(JSON,default=dict)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class Script(Base):
    __tablename__="scripts"
    id:Mapped[int]=mapped_column(primary_key=True)
    project_id:Mapped[int]=mapped_column(ForeignKey("content_projects.id"),index=True)
    version:Mapped[int]=mapped_column(Integer,default=1)
    title:Mapped[str]=mapped_column(String(500))
    body:Mapped[str]=mapped_column(Text)
    outline_json:Mapped[dict]=mapped_column(JSON,default=dict)
    sources_json:Mapped[list]=mapped_column(JSON,default=list)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class ScenePlan(Base):
    __tablename__="scene_plans"
    id:Mapped[int]=mapped_column(primary_key=True)
    project_id:Mapped[int]=mapped_column(ForeignKey("content_projects.id"),index=True)
    version:Mapped[int]=mapped_column(Integer,default=1)
    scenes_json:Mapped[list]=mapped_column(JSON,default=list)

class VideoProject(Base):
    __tablename__="video_projects"
    id:Mapped[int]=mapped_column(primary_key=True)
    project_id:Mapped[int]=mapped_column(ForeignKey("content_projects.id"),unique=True)
    status:Mapped[str]=mapped_column(String(50),default="queued")
    render_path:Mapped[str|None]=mapped_column(String(2000))
    duration_seconds:Mapped[int|None]=mapped_column(Integer)

class Thumbnail(Base):
    __tablename__="thumbnails"
    id:Mapped[int]=mapped_column(primary_key=True)
    project_id:Mapped[int]=mapped_column(ForeignKey("content_projects.id"),index=True)
    prompt:Mapped[str]=mapped_column(Text)
    image_path:Mapped[str|None]=mapped_column(String(2000))
    score:Mapped[int|None]=mapped_column(Integer)

class WorkflowRun(Base):
    __tablename__="workflow_runs"
    id:Mapped[int]=mapped_column(primary_key=True)
    project_id:Mapped[int]=mapped_column(ForeignKey("content_projects.id"),index=True)
    idempotency_key:Mapped[str]=mapped_column(String(255),unique=True)
    status:Mapped[str]=mapped_column(String(50),default="queued")
    current_step:Mapped[str]=mapped_column(String(80),default="queued")
    progress:Mapped[int]=mapped_column(Integer,default=0)
    error:Mapped[str|None]=mapped_column(Text)
    result_json:Mapped[dict]=mapped_column(JSON,default=dict)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class UsageEvent(Base):
    __tablename__="usage_events"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    event_type:Mapped[str]=mapped_column(String(80))
    units:Mapped[int]=mapped_column(BigInteger,default=1)
    metadata_json:Mapped[dict]=mapped_column(JSON,default=dict)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class AuditLog(Base):
    __tablename__="audit_logs"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    user_id:Mapped[int|None]=mapped_column(ForeignKey("users.id"))
    action:Mapped[str]=mapped_column(String(120))
    metadata_json:Mapped[dict]=mapped_column(JSON,default=dict)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=now)

class AnalyticsDaily(Base):
    __tablename__="analytics_daily"
    id:Mapped[int]=mapped_column(primary_key=True)
    channel_id:Mapped[int]=mapped_column(ForeignKey("channels.id"),index=True)
    video_external_id:Mapped[str]=mapped_column(String(255),index=True)
    date_key:Mapped[str]=mapped_column(String(20),index=True)
    views:Mapped[int]=mapped_column(BigInteger,default=0)
    watch_time_minutes:Mapped[int]=mapped_column(BigInteger,default=0)
    subscribers_gained:Mapped[int]=mapped_column(Integer,default=0)
    ctr:Mapped[float]=mapped_column(default=0)
    __table_args__=(UniqueConstraint("video_external_id","date_key",name="uq_video_date"),)


class ContentAsset(Base):
    __tablename__="content_assets"
    id:Mapped[int]=mapped_column(primary_key=True)
    project_id:Mapped[int]=mapped_column(ForeignKey("content_projects.id"),index=True)
    asset_type:Mapped[str]=mapped_column(String(50))
    source_url:Mapped[str|None]=mapped_column(String(2000))
    local_path:Mapped[str|None]=mapped_column(String(2000))
    license_json:Mapped[dict]=mapped_column(JSON,default=dict)
    status:Mapped[str]=mapped_column(String(40),default="ready")

class VideoMetricSnapshot(Base):
    __tablename__="video_metric_snapshots"
    id:Mapped[int]=mapped_column(primary_key=True)
    channel_id:Mapped[int]=mapped_column(ForeignKey("channels.id"),index=True)
    video_external_id:Mapped[str]=mapped_column(String(255),index=True)
    captured_at:Mapped[datetime]=mapped_column(DateTime,default=now)
    views:Mapped[int]=mapped_column(BigInteger,default=0)
    watch_time_minutes:Mapped[int]=mapped_column(BigInteger,default=0)
    likes:Mapped[int]=mapped_column(BigInteger,default=0)
    comments:Mapped[int]=mapped_column(BigInteger,default=0)
    subscribers_gained:Mapped[int]=mapped_column(Integer,default=0)

class PublishingJob(Base):
    __tablename__="publishing_jobs"
    id:Mapped[int]=mapped_column(primary_key=True)
    project_id:Mapped[int]=mapped_column(ForeignKey("content_projects.id"),index=True)
    channel_id:Mapped[int]=mapped_column(ForeignKey("channels.id"),index=True)
    status:Mapped[str]=mapped_column(String(40),default="queued")
    scheduled_at:Mapped[datetime|None]=mapped_column(DateTime)
    external_video_id:Mapped[str|None]=mapped_column(String(255))
    error:Mapped[str|None]=mapped_column(Text)
