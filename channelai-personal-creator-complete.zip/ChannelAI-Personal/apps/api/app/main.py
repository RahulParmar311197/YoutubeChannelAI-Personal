from fastapi import FastAPI
from .middleware import RequestIDMiddleware
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .routers import health, auth, channels, projects, ai, youtube, billing, autopilot, publishing, learning, calendar, workflows, strategy, generate, publish_gate, onboarding, seo, pipeline, release

app = FastAPI(title="ChannelAI API", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.web_origin],
    allow_credentials=True,
    allow_methods=["GET","POST","PUT","PATCH","DELETE","OPTIONS"],
    allow_headers=["Authorization","Content-Type","Idempotency-Key"],
)
app.add_middleware(RequestIDMiddleware)

app.include_router(health.router)
app.include_router(auth.router)
app.include_router(channels.router)
app.include_router(projects.router)
app.include_router(ai.router)
app.include_router(youtube.router)
app.include_router(billing.router)
app.include_router(autopilot.router)
app.include_router(publishing.router)
app.include_router(learning, calendar, workflows, strategy, generate, publish_gate, onboarding, seo, pipeline, release.router)
