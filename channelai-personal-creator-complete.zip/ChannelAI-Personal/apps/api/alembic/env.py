import asyncio, os
from logging.config import fileConfig
from alembic import context
from sqlalchemy.ext.asyncio import create_async_engine
from app.models import Base
config=context.config
if config.config_file_name: fileConfig(config.config_file_name)
target_metadata=Base.metadata
def run_migrations():
    url=os.getenv("DATABASE_URL",config.get_main_option("sqlalchemy.url"))
    engine=create_async_engine(url)
    async def go():
        async with engine.begin() as conn:
            await conn.run_sync(lambda c: context.configure(connection=c,target_metadata=target_metadata))
            await conn.run_sync(lambda c: context.run_migrations())
    asyncio.run(go())
run_migrations()
