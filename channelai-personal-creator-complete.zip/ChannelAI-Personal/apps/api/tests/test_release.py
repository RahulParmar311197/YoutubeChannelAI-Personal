from apps.api.app.services.publishing_gate import can_publish
from apps.api.app.services.usage import within_generation_limit
from apps.api.app.services.pipeline import STAGES

def test_pipeline_complete():
    assert STAGES[-1] == ("ready",100)

def test_publish_gate_blocks_without_approval():
    x=can_publish(qc_passed=True,moderation_passed=True,approval_required=True,
                  approved=False,youtube_connected=True,quota_available=True)
    assert not x["allowed"] and "approval_required" in x["flags"]

def test_usage_limit():
    assert within_generation_limit("starter",9)
    assert not within_generation_limit("starter",10)
