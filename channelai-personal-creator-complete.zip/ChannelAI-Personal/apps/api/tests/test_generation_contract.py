def test_generation_contract():
    required_steps=["research","script","scene_plan","voice","render","qc","completed"]
    assert required_steps == ["research","script","scene_plan","voice","render","qc","completed"]

def test_publish_gate_requires_ready():
    assert "video_not_ready" in ["video_not_ready"]
