from apps.api.app.services.seo import optimize
from apps.api.app.services.onboarding import checklist

def test_seo():
    x=optimize("  My Video  ","description",["youtube","youtube","AI"])
    assert x["title"]=="My Video"
    assert len(x["tags"])==2

def test_onboarding():
    x=checklist(False,False,False)
    assert len(x)==3 and not any(i["done"] for i in x)
