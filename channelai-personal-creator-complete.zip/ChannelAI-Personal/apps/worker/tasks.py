import os, asyncio
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy import select
from apps.api.app.config import settings
from apps.api.app.models import PublishingJob, ContentProject, VideoProject, Channel
from apps.api.app.services.youtube import upload_video, get_channel_for_org

engine=create_async_engine(settings.database_url)
Session=async_sessionmaker(engine,expire_on_commit=False)

async def process_due_publishing_jobs():
    async with Session() as db:
        now=datetime.now(timezone.utc).replace(tzinfo=None)
        rows=(await db.execute(select(PublishingJob).where(
            PublishingJob.status=="queued",
            PublishingJob.scheduled_at<=now
        ).limit(10))).scalars().all()
        for job in rows:
            try:
                project=await db.get(ContentProject,job.project_id)
                channel=await db.get(Channel,job.channel_id)
                video=await db.scalar(select(VideoProject).where(VideoProject.project_id==project.id))
                if not video or not video.render_path:
                    raise RuntimeError("Rendered video is not ready")
                result=upload_video(channel,video.render_path,project.title,project.topic,[],privacy_status="public")
                job.external_video_id=result.get("id")
                job.status="published"
                project.status="published"
            except Exception as exc:
                job.status="failed"; job.error=str(exc)
        await db.commit()

def run_due_jobs():
    asyncio.run(process_due_publishing_jobs())
