from pathlib import Path
import subprocess

def render_single_clip(input_file: str, output_file: str):
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    return subprocess.run(
        ["ffmpeg", "-y", "-i", input_file, "-c:v", "libx264", "-pix_fmt", "yuv420p", output_file],
        check=True
    )
