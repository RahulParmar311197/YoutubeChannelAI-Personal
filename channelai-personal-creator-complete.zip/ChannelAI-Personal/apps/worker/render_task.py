import asyncio, os
from pathlib import Path
from apps.api.app.services.tts import get_tts_provider
from apps.api.app.services.render import RenderService

async def render_project(project_id:int,script_text:str):
    root=Path(os.getenv("MEDIA_ROOT","./storage"))/str(project_id)
    root.mkdir(parents=True,exist_ok=True)
    voice=root/"voice.wav"
    out=root/"final.mp4"
    await get_tts_provider().synthesize(script_text,str(voice))
    return await RenderService().render(project_id,[{"index":1}], [str(voice)], str(out))

if __name__=="__main__":
    raise SystemExit("Import render_project from the RQ job runner.")
