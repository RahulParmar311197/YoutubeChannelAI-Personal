import os
from redis import Redis
from rq import Queue, Worker
from jobs import generate_project

if __name__=="__main__":
    redis=Redis.from_url(os.getenv("REDIS_URL","redis://localhost:6379/0"))
    q=Queue("generation",connection=redis)
    Worker([q],name="channelai-generation-worker").work()
