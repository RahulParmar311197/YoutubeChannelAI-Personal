import asyncio
from sqlalchemy.ext.asyncio import create_async_engine,async_sessionmaker
from apps.api.app.config import settings
from apps.api.app.services.orchestrator import GenerationOrchestrator

engine=create_async_engine(settings.database_url,pool_pre_ping=True)
Session=async_sessionmaker(engine,expire_on_commit=False)

def generate_project(run_id:int):
    async def inner():
        async with Session() as db:
            return await GenerationOrchestrator().run(db,run_id)
    return asyncio.run(inner())
