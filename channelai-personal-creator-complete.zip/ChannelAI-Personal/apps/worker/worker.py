import os
from redis import Redis
from rq import Queue, Worker

redis=Redis.from_url(os.getenv("REDIS_URL","redis://localhost:6379/0"))
if __name__=="__main__":
    Worker([Queue("default",connection=redis)],name="channelai-worker").work()
