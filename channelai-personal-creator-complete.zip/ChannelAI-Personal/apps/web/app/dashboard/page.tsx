"use client";
import {useEffect,useState} from "react";
export default function Dashboard(){
 const [status,setStatus]=useState<any>(null);
 const [channel,setChannel]=useState("");
 const API=process.env.NEXT_PUBLIC_API_URL||"http://localhost:8000";
 const token=typeof window!=="undefined"?localStorage.getItem("token"):"";
 async function load(){
  const r=await fetch(`${API}/api/onboarding/checklist`,{headers:{Authorization:`Bearer ${token}`}});
  setStatus(await r.json());
 }
 useEffect(()=>{load()},[]);
 return <main style={{maxWidth:1100,margin:"40px auto",padding:24,fontFamily:"Inter,system-ui"}}>
  <header style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
   <div><h1>ChannelAI</h1><p>AI YouTube production studio</p></div>
   <button onClick={load}>Refresh</button>
  </header>
  <section style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16,marginTop:24}}>
   <div style={{padding:20,border:"1px solid #ddd",borderRadius:12}}><b>Discover</b><p>Find topics with channel strategy.</p></div>
   <div style={{padding:20,border:"1px solid #ddd",borderRadius:12}}><b>Produce</b><p>Script, voice, visuals and render.</p></div>
   <div style={{padding:20,border:"1px solid #ddd",borderRadius:12}}><b>Publish</b><p>QC, schedule and analyze.</p></div>
  </section>
  <section style={{marginTop:28}}>
   <h2>Launch checklist</h2>
   {(status?.items||[]).map((x:any)=><div key={x.key} style={{padding:12,borderBottom:"1px solid #eee"}}>{x.done?"✓":"○"} {x.label}</div>)}
  </section>
 </main>
}
