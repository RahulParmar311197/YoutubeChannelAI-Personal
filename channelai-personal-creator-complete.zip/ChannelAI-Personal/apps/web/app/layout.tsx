import "./globals.css";

export const metadata = {
  title: "ChannelAI",
  description: "AI YouTube Channel Operating System"
};

export default function Layout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
