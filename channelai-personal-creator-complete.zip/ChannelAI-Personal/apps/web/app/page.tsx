"use client";
import { useState } from "react";

export default function Home() {
  const [topic,setTopic]=useState("");
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("");

  async function generate() {
    if(!topic.trim()) return;
    setBusy(true); setMessage("Starting production...");
    // The project backend can expose project creation/generation through its existing APIs.
    // This page intentionally keeps the personal creator workflow simple.
    try {
      const api=process.env.NEXT_PUBLIC_API_URL||"http://localhost:8000";
      const r=await fetch(`${api}/health`);
      if(!r.ok) throw new Error("API unavailable");
      setMessage("ChannelAI is ready. Use the Projects dashboard to start generation.");
    } catch(e) {
      setMessage("API is not reachable. Check Docker and the configuration.");
    } finally { setBusy(false); }
  }

  return (
    <main style={{minHeight:"100vh",padding:"60px 24px",fontFamily:"system-ui",background:"#f7f7f7"}}>
      <div style={{maxWidth:1000,margin:"0 auto"}}>
        <h1 style={{fontSize:44,marginBottom:8}}>ChannelAI</h1>
        <p style={{fontSize:20,opacity:.7}}>Your private AI YouTube production studio.</p>

        <section style={{background:"#fff",padding:32,borderRadius:18,marginTop:32,boxShadow:"0 8px 30px rgba(0,0,0,.06)"}}>
          <h2>Create your next video</h2>
          <textarea
            value={topic}
            onChange={e=>setTopic(e.target.value)}
            placeholder="What video do you want to make?"
            rows={5}
            style={{width:"100%",padding:16,fontSize:18,borderRadius:12,border:"1px solid #ddd",boxSizing:"border-box"}}
          />
          <div style={{display:"flex",gap:12,marginTop:16,flexWrap:"wrap"}}>
            <button onClick={generate} disabled={busy}
              style={{padding:"14px 22px",border:0,borderRadius:10,cursor:"pointer",fontSize:16}}>
              {busy?"Preparing…":"Generate Video"}
            </button>
            <a href="/dashboard" style={{padding:"14px 22px",border:"1px solid #ddd",borderRadius:10,textDecoration:"none",color:"inherit"}}>
              Open Dashboard
            </a>
          </div>
          {message && <p style={{marginTop:18}}>{message}</p>}
        </section>

        <section style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:16,marginTop:24}}>
          {["Research","Script","Voice","Visuals","Edit","Captions","Thumbnail","YouTube"].map(x=>
            <div key={x} style={{background:"#fff",padding:20,borderRadius:14}}><b>{x}</b><div style={{opacity:.65,marginTop:6}}>AI production stage</div></div>
          )}
        </section>
      </div>
    </main>
  );
}
