#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL required}"
: "${BACKUP_FILE:?BACKUP_FILE required}"
pg_restore --clean --if-exists --dbname="$DATABASE_URL" "$BACKUP_FILE"
echo "restore complete"
