# Production deployment

1. Provision a Linux VM or container host with Docker and PostgreSQL backup storage.
2. Copy `.env.production.example` to `.env.production` and replace every secret.
3. Configure a real domain and TLS certificate.
4. Configure AI, research, TTS, media, YouTube OAuth and Stripe credentials.
5. Run database migrations before starting workers.
6. Start `docker compose -f infra/docker-compose.prod.yml up -d --build`.
7. Verify `/health` and `/ready`.
8. Run a private/unlisted end-to-end video generation test.
9. Verify YouTube upload, analytics, retries and audit logs.
10. Enable public scheduled publishing only after QC and moderation are validated.
11. Configure daily database backups and periodically test restore.
12. Configure error monitoring and alerting.

Never commit `.env.production`, OAuth secrets, encryption keys or provider credentials.
