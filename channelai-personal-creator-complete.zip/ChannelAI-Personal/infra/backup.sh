#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL required}"
: "${BACKUP_DIR:=./backups}"
mkdir -p "$BACKUP_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
pg_dump "$DATABASE_URL" --format=custom --file="$BACKUP_DIR/channelai-$STAMP.dump"
find "$BACKUP_DIR" -type f -mtime +14 -delete
echo "backup=$BACKUP_DIR/channelai-$STAMP.dump"
