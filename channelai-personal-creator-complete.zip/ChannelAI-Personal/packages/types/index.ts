export type ProjectStatus =
  | "idea" | "researching" | "scripting" | "producing"
  | "ready" | "published" | "failed";

export interface VideoIdea {
  title: string;
  score: number;
  reason?: string;
}

export interface Scene {
  index: number;
  duration: number;
  narration: string;
  visualPrompt: string;
  caption?: string;
}
