#!/usr/bin/env bash
set -euo pipefail

echo "=== ChannelAI Production Bootstrap ==="

if [ ! -f .env.production ]; then
  cp .env.production.example .env.production
  echo "Created .env.production from template."
  echo "IMPORTANT: edit .env.production with your real provider credentials."
fi

docker compose -f infra/docker-compose.prod.yml build
docker compose -f infra/docker-compose.prod.yml up -d

echo "Waiting for API..."
for i in $(seq 1 30); do
  if curl -fsS http://localhost/health >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

docker compose -f infra/docker-compose.prod.yml exec -T api alembic upgrade head || true

echo
echo "ChannelAI is running."
echo "Web: http://localhost"
echo "API: http://localhost/health"
echo "Configuration: http://localhost/api/system/configuration"
