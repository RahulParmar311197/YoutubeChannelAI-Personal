#!/usr/bin/env bash
set -euo pipefail
VERSION="${1:-v9.0.0}"
echo "Releasing ChannelAI ${VERSION}"
docker compose -f infra/docker-compose.prod.yml config >/dev/null
docker compose -f infra/docker-compose.prod.yml build
docker compose -f infra/docker-compose.prod.yml up -d
curl --fail --retry 10 http://localhost/health || true
echo "Release deployed: ${VERSION}"
