#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

if [ ! -f .env ]; then
  cp .env.personal.example .env
  echo "Created .env from .env.personal.example"
  echo "Edit .env and add your provider credentials, then rerun this script."
  exit 0
fi

docker compose -f infra/docker-compose.personal.yml up -d --build

echo "Waiting for API..."
for i in $(seq 1 40); do
  if curl -fsS http://localhost:8000/health >/dev/null 2>&1; then break; fi
  sleep 2
done

docker compose -f infra/docker-compose.personal.yml exec -T api alembic upgrade head || true

echo
echo "========================================"
echo " ChannelAI Personal Creator is running "
echo "========================================"
echo " Dashboard: http://localhost:3000"
echo " API:       http://localhost:8000"
echo
echo "Open the dashboard, connect YouTube, and generate your first video."
