#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE_URL:-http://localhost}"
curl --fail "$BASE/health"
curl --fail "$BASE/ready"
echo "Smoke tests passed"
