import os,sys
from pathlib import Path
required=[
"SECRET_KEY","TOKEN_ENCRYPTION_KEY","DATABASE_URL","REDIS_URL",
"AI_API_KEY","AI_MODEL","RESEARCH_API_KEY","RESEARCH_API_BASE_URL",
"TTS_API_KEY","TTS_API_BASE_URL","TTS_VOICE_ID",
"MEDIA_API_KEY","MEDIA_API_BASE_URL","S3_BUCKET","S3_ENDPOINT",
"S3_REGION","S3_ACCESS_KEY","S3_SECRET_KEY",
"GOOGLE_CLIENT_ID","GOOGLE_CLIENT_SECRET",
"STRIPE_SECRET_KEY","STRIPE_WEBHOOK_SECRET",
"SMTP_HOST","SMTP_USERNAME","SMTP_PASSWORD"
]
missing=[x for x in required if not os.getenv(x)]
if missing:
    print("MISSING:")
    print("\n".join(missing))
    sys.exit(1)
print("Production configuration looks complete.")
